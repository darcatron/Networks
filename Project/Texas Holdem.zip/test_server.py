import Server

test_server = Server() # create an instance of the Server class
test_server.start(8000) # start the server locally on any open port